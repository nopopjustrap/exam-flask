from __future__ import annotations

import hashlib
import os
import re
import sqlite3
from functools import wraps
from pathlib import Path

import bleach
import markdown
from flask import (
    Flask,
    abort,
    current_app,
    flash,
    g,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)
from markupsafe import Markup
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}
AUTH_REQUIRED_MESSAGE = (
    "Для выполнения данного действия необходимо пройти процедуру аутентификации"
)
FORBIDDEN_MESSAGE = "У вас недостаточно прав для выполнения данного действия"
RATING_LABELS = {
    5: "отлично",
    4: "хорошо",
    3: "удовлетворительно",
    2: "неудовлетворительно",
    1: "плохо",
    0: "ужасно",
}


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY="change-me-before-production",
        DATABASE=str(BASE_DIR / "library.db"),
        UPLOAD_FOLDER=str(BASE_DIR / "uploads"),
        MAX_CONTENT_LENGTH=5 * 1024 * 1024,
        AUTHOR_LINE="Мельников Кирилл, 241-372",
    )
    if test_config:
        app.config.update(test_config)

    Path(app.config["UPLOAD_FOLDER"]).mkdir(parents=True, exist_ok=True)
    app.teardown_appcontext(close_db)
    register_template_helpers(app)
    register_routes(app)

    with app.app_context():
        init_db()
        seed_db()
    return app


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_exception=None) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db() -> None:
    db = get_db()
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            login TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            last_name TEXT NOT NULL,
            first_name TEXT NOT NULL,
            middle_name TEXT,
            role_id INTEGER NOT NULL REFERENCES roles(id)
        );
        CREATE TABLE IF NOT EXISTS genres (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            publication_year INTEGER NOT NULL,
            publisher TEXT NOT NULL,
            author TEXT NOT NULL,
            pages INTEGER NOT NULL CHECK (pages > 0)
        );
        CREATE TABLE IF NOT EXISTS book_genres (
            book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
            genre_id INTEGER NOT NULL REFERENCES genres(id),
            PRIMARY KEY (book_id, genre_id)
        );
        CREATE TABLE IF NOT EXISTS covers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            mime_type TEXT NOT NULL,
            md5_hash TEXT NOT NULL,
            book_id INTEGER NOT NULL UNIQUE REFERENCES books(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS review_statuses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
            user_id INTEGER NOT NULL REFERENCES users(id),
            rating INTEGER NOT NULL CHECK (rating BETWEEN 0 AND 5),
            text TEXT NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status_id INTEGER NOT NULL REFERENCES review_statuses(id),
            UNIQUE(book_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS collections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS collection_books (
            collection_id INTEGER NOT NULL REFERENCES collections(id) ON DELETE CASCADE,
            book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
            PRIMARY KEY (collection_id, book_id)
        );
        """
    )
    db.commit()


def seed_db() -> None:
    db = get_db()
    roles = [
        ("Администратор", "Полный доступ к системе"),
        ("Модератор", "Редактирование книг и модерация рецензий"),
        ("Пользователь", "Создание рецензий"),
    ]
    statuses = ["На рассмотрении", "Одобрена", "Отклонена"]
    genres = ["Классика", "Фантастика", "Детектив", "Научная литература", "Роман"]
    db.executemany(
        "INSERT OR IGNORE INTO roles(name, description) VALUES (?, ?)", roles
    )
    db.executemany(
        "INSERT OR IGNORE INTO review_statuses(name) VALUES (?)",
        [(status,) for status in statuses],
    )
    db.executemany(
        "INSERT OR IGNORE INTO genres(name) VALUES (?)",
        [(genre,) for genre in genres],
    )
    role_ids = {
        row["name"]: row["id"] for row in db.execute("SELECT id, name FROM roles")
    }
    users = [
        ("admin", "admin", "Иванов", "Иван", "Иванович", "Администратор"),
        ("moderator", "moderator", "Петров", "Пётр", "Петрович", "Модератор"),
        ("reader", "reader", "Сидорова", "Анна", None, "Пользователь"),
    ]
    for login, password, last_name, first_name, middle_name, role in users:
        db.execute(
            """
            INSERT OR IGNORE INTO users(
                login, password_hash, last_name, first_name, middle_name, role_id
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                login,
                generate_password_hash(password),
                last_name,
                first_name,
                middle_name,
                role_ids[role],
            ),
        )

    if db.execute("SELECT COUNT(*) AS count FROM books").fetchone()["count"] == 0:
        sample_books = [
            (
                "Мастер и Маргарита",
                "Роман о добре, зле и свободе выбора.",
                1967,
                "YMCA-Press",
                "Михаил Булгаков",
                480,
                ["Классика", "Роман"],
            ),
            (
                "Пикник на обочине",
                "Научно-фантастическая повесть о последствиях **Посещения**.",
                1972,
                "Аврора",
                "Аркадий и Борис Стругацкие",
                224,
                ["Фантастика"],
            ),
            (
                "Изучаем Flask",
                "Практическое введение в разработку веб-приложений на Python.",
                2024,
                "Учебное издательство",
                "Коллектив авторов",
                320,
                ["Научная литература"],
            ),
        ]
        genre_ids = {
            row["name"]: row["id"]
            for row in db.execute("SELECT id, name FROM genres")
        }
        for title, description, year, publisher, author, pages, book_genres in sample_books:
            cursor = db.execute(
                """
                INSERT INTO books(
                    title, description, publication_year, publisher, author, pages
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (title, description, year, publisher, author, pages),
            )
            db.executemany(
                "INSERT INTO book_genres(book_id, genre_id) VALUES (?, ?)",
                [(cursor.lastrowid, genre_ids[name]) for name in book_genres],
            )
    db.commit()


def register_template_helpers(app: Flask) -> None:
    @app.before_request
    def load_current_user() -> None:
        g.flask_app = app
        user_id = session.get("user_id")
        g.user = (
            get_db()
            .execute(
                """
                SELECT users.*, roles.name AS role_name
                FROM users JOIN roles ON roles.id = users.role_id
                WHERE users.id = ?
                """,
                (user_id,),
            )
            .fetchone()
            if user_id
            else None
        )

    @app.context_processor
    def inject_globals() -> dict:
        return {
            "current_user": g.get("user"),
            "rating_labels": RATING_LABELS,
            "author_line": app.config["AUTHOR_LINE"],
        }

    @app.template_filter("markdown")
    def markdown_filter(text: str) -> Markup:
        html = markdown.markdown(text or "", extensions=["extra"])
        cleaned = bleach.clean(
            html,
            tags=[
                "p",
                "br",
                "strong",
                "em",
                "ul",
                "ol",
                "li",
                "blockquote",
                "code",
                "pre",
                "h1",
                "h2",
                "h3",
                "a",
            ],
            attributes={"a": ["href", "title"]},
            protocols=["http", "https", "mailto"],
            strip=True,
        )
        return Markup(cleaned)


def sanitize_markdown(text: str) -> str:
    return bleach.clean(text or "", tags=[], attributes={}, strip=True).strip()


def login_required(view):
    @wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            flash(AUTH_REQUIRED_MESSAGE, "warning")
            return redirect(url_for("login", next=request.full_path))
        return view(**kwargs)

    return wrapped_view


def roles_required(*allowed_roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped_view(**kwargs):
            if g.user["role_name"] not in allowed_roles:
                flash(FORBIDDEN_MESSAGE, "danger")
                return redirect(url_for("index"))
            return view(**kwargs)

        return wrapped_view

    return decorator


def get_book(book_id: int):
    book = (
        get_db()
        .execute(
            """
            SELECT books.*, covers.filename AS cover_filename,
                   covers.mime_type AS cover_mime_type,
                   GROUP_CONCAT(genres.name, ', ') AS genre_names,
                   ROUND(AVG(CASE WHEN review_statuses.name = 'Одобрена'
                             THEN reviews.rating END), 1) AS average_rating,
                   COUNT(DISTINCT CASE WHEN review_statuses.name = 'Одобрена'
                                      THEN reviews.id END) AS reviews_count
            FROM books
            LEFT JOIN covers ON covers.book_id = books.id
            LEFT JOIN book_genres ON book_genres.book_id = books.id
            LEFT JOIN genres ON genres.id = book_genres.genre_id
            LEFT JOIN reviews ON reviews.book_id = books.id
            LEFT JOIN review_statuses ON review_statuses.id = reviews.status_id
            WHERE books.id = ?
            GROUP BY books.id
            """,
            (book_id,),
        )
        .fetchone()
    )
    if book is None:
        abort(404)
    return book


def get_review(review_id: int):
    review = (
        get_db()
        .execute(
            """
            SELECT reviews.*, books.title AS book_title,
                   review_statuses.name AS status_name,
                   users.last_name || ' ' || users.first_name ||
                   CASE WHEN users.middle_name IS NULL THEN ''
                        ELSE ' ' || users.middle_name END AS user_name
            FROM reviews
            JOIN books ON books.id = reviews.book_id
            JOIN users ON users.id = reviews.user_id
            JOIN review_statuses ON review_statuses.id = reviews.status_id
            WHERE reviews.id = ?
            """,
            (review_id,),
        )
        .fetchone()
    )
    if review is None:
        abort(404)
    return review


def get_collection(collection_id: int):
    collection = (
        get_db()
        .execute(
            """
            SELECT collections.*, COUNT(collection_books.book_id) AS books_count
            FROM collections
            LEFT JOIN collection_books
                   ON collection_books.collection_id = collections.id
            WHERE collections.id = ? AND collections.user_id = ?
            GROUP BY collections.id
            """,
            (collection_id, g.user["id"]),
        )
        .fetchone()
    )
    if collection is None:
        abort(404)
    return collection


def validate_book_form(require_cover: bool) -> tuple[dict, list[str], object]:
    form = {
        "title": request.form.get("title", "").strip(),
        "description": sanitize_markdown(request.form.get("description", "")),
        "publication_year": request.form.get("publication_year", "").strip(),
        "publisher": request.form.get("publisher", "").strip(),
        "author": request.form.get("author", "").strip(),
        "pages": request.form.get("pages", "").strip(),
        "genre_ids": request.form.getlist("genre_ids"),
    }
    cover = request.files.get("cover")
    errors = []
    for field, label in [
        ("title", "Название"),
        ("description", "Описание"),
        ("publication_year", "Год"),
        ("publisher", "Издательство"),
        ("author", "Автор"),
        ("pages", "Объём"),
    ]:
        if not form[field]:
            errors.append(f"Поле «{label}» обязательно.")
    if not form["genre_ids"]:
        errors.append("Выберите хотя бы один жанр.")
    try:
        year = int(form["publication_year"])
        if not 1 <= year <= 2100:
            raise ValueError
    except ValueError:
        errors.append("Год должен быть числом от 1 до 2100.")
    try:
        pages = int(form["pages"])
        if pages <= 0:
            raise ValueError
    except ValueError:
        errors.append("Количество страниц должно быть положительным числом.")
    if require_cover and (not cover or not cover.filename):
        errors.append("Добавьте обложку книги.")
    if cover and cover.filename and not allowed_file(cover.filename):
        errors.append("Обложка должна иметь формат PNG, JPG, GIF или WEBP.")
    return form, errors, cover


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def save_cover_record(db, book_id: int, cover) -> None:
    data = cover.read()
    md5_hash = hashlib.md5(data).hexdigest()
    extension = cover.filename.rsplit(".", 1)[1].lower()
    filename = f"{md5_hash}.{extension}"
    upload_path = Path(current_app.config["UPLOAD_FOLDER"]) / filename
    if not upload_path.exists():
        upload_path.write_bytes(data)
    db.execute(
        """
        INSERT INTO covers(filename, mime_type, md5_hash, book_id)
        VALUES (?, ?, ?, ?)
        """,
        (filename, cover.mimetype or "application/octet-stream", md5_hash, book_id),
    )


def delete_unused_cover_file(filename: str) -> None:
    if not filename:
        return
    count = (
        get_db()
        .execute("SELECT COUNT(*) AS count FROM covers WHERE filename = ?", (filename,))
        .fetchone()["count"]
    )
    if count == 0:
        path = Path(current_app.config["UPLOAD_FOLDER"]) / filename
        if path.exists():
            path.unlink()


def register_routes(app: Flask) -> None:
    @app.route("/")
    def index():
        page = max(request.args.get("page", 1, type=int), 1)
        per_page = 10
        db = get_db()
        total = db.execute("SELECT COUNT(*) AS count FROM books").fetchone()["count"]
        books = db.execute(
            """
            SELECT books.*, covers.filename AS cover_filename,
                   GROUP_CONCAT(DISTINCT genres.name) AS genre_names,
                   ROUND(AVG(CASE WHEN review_statuses.name = 'Одобрена'
                             THEN reviews.rating END), 1) AS average_rating,
                   COUNT(DISTINCT CASE WHEN review_statuses.name = 'Одобрена'
                                      THEN reviews.id END) AS reviews_count
            FROM books
            LEFT JOIN covers ON covers.book_id = books.id
            LEFT JOIN book_genres ON book_genres.book_id = books.id
            LEFT JOIN genres ON genres.id = book_genres.genre_id
            LEFT JOIN reviews ON reviews.book_id = books.id
            LEFT JOIN review_statuses ON review_statuses.id = reviews.status_id
            GROUP BY books.id
            ORDER BY books.publication_year DESC, books.title
            LIMIT ? OFFSET ?
            """,
            (per_page, (page - 1) * per_page),
        ).fetchall()
        pages = max((total + per_page - 1) // per_page, 1)
        return render_template("index.html", books=books, page=page, pages=pages)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            user = get_db().execute(
                """
                SELECT users.*, roles.name AS role_name
                FROM users JOIN roles ON roles.id = users.role_id
                WHERE login = ?
                """,
                (request.form.get("login", "").strip(),),
            ).fetchone()
            if user and check_password_hash(
                user["password_hash"], request.form.get("password", "")
            ):
                session.clear()
                session["user_id"] = user["id"]
                session.permanent = bool(request.form.get("remember"))
                return redirect(request.args.get("next") or url_for("index"))
            flash(
                "Невозможно аутентифицироваться с указанными логином и паролем",
                "danger",
            )
        return render_template("login.html")

    @app.post("/logout")
    def logout():
        session.clear()
        return redirect(request.referrer or url_for("index"))

    @app.route("/books/<int:book_id>")
    def book_detail(book_id):
        db = get_db()
        book = get_book(book_id)
        reviews = db.execute(
            """
            SELECT reviews.*, users.last_name || ' ' || users.first_name AS user_name
            FROM reviews
            JOIN users ON users.id = reviews.user_id
            JOIN review_statuses ON review_statuses.id = reviews.status_id
            WHERE reviews.book_id = ? AND review_statuses.name = 'Одобрена'
            ORDER BY reviews.created_at DESC
            """,
            (book_id,),
        ).fetchall()
        user_review = None
        collections = []
        if g.user:
            user_review = db.execute(
                """
                SELECT reviews.*, review_statuses.name AS status_name
                FROM reviews JOIN review_statuses ON review_statuses.id = reviews.status_id
                WHERE reviews.book_id = ? AND reviews.user_id = ?
                """,
                (book_id, g.user["id"]),
            ).fetchone()
            if g.user["role_name"] == "Пользователь":
                collections = db.execute(
                    """
                    SELECT id, title FROM collections
                    WHERE user_id = ?
                    ORDER BY title
                    """,
                    (g.user["id"],),
                ).fetchall()
        return render_template(
            "book_detail.html",
            book=book,
            reviews=reviews,
            user_review=user_review,
            collections=collections,
        )

    @app.route("/uploads/<path:filename>")
    def uploaded_file(filename):
        return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

    @app.route("/books/new", methods=["GET", "POST"])
    @roles_required("Администратор")
    def book_create():
        db = get_db()
        genres = db.execute("SELECT * FROM genres ORDER BY name").fetchall()
        form = {}
        if request.method == "POST":
            form, errors, cover = validate_book_form(require_cover=True)
            if not errors:
                try:
                    cursor = db.execute(
                        """
                        INSERT INTO books(
                            title, description, publication_year, publisher, author, pages
                        ) VALUES (?, ?, ?, ?, ?, ?)
                        """,
                        (
                            form["title"],
                            form["description"],
                            int(form["publication_year"]),
                            form["publisher"],
                            form["author"],
                            int(form["pages"]),
                        ),
                    )
                    book_id = cursor.lastrowid
                    db.executemany(
                        "INSERT INTO book_genres(book_id, genre_id) VALUES (?, ?)",
                        [(book_id, genre_id) for genre_id in form["genre_ids"]],
                    )
                    save_cover_record(db, book_id, cover)
                    db.commit()
                    flash("Книга успешно добавлена.", "success")
                    return redirect(url_for("book_detail", book_id=book_id))
                except Exception:
                    db.rollback()
                    flash("При сохранении данных возникла ошибка.", "danger")
            for error in errors:
                flash(error, "danger")
        return render_template("book_form.html", form=form, genres=genres, book=None)

    @app.route("/books/<int:book_id>/edit", methods=["GET", "POST"])
    @roles_required("Администратор", "Модератор")
    def book_edit(book_id):
        db = get_db()
        book = get_book(book_id)
        genres = db.execute("SELECT * FROM genres ORDER BY name").fetchall()
        selected_genres = [
            str(row["genre_id"])
            for row in db.execute(
                "SELECT genre_id FROM book_genres WHERE book_id = ?", (book_id,)
            )
        ]
        form = dict(book)
        form["genre_ids"] = selected_genres
        if request.method == "POST":
            form, errors, cover = validate_book_form(require_cover=False)
            if not errors:
                old_cover = book["cover_filename"]
                try:
                    db.execute(
                        """
                        UPDATE books SET title = ?, description = ?,
                            publication_year = ?, publisher = ?, author = ?, pages = ?
                        WHERE id = ?
                        """,
                        (
                            form["title"],
                            form["description"],
                            int(form["publication_year"]),
                            form["publisher"],
                            form["author"],
                            int(form["pages"]),
                            book_id,
                        ),
                    )
                    db.execute("DELETE FROM book_genres WHERE book_id = ?", (book_id,))
                    db.executemany(
                        "INSERT INTO book_genres(book_id, genre_id) VALUES (?, ?)",
                        [(book_id, genre_id) for genre_id in form["genre_ids"]],
                    )
                    if cover and cover.filename:
                        db.execute("DELETE FROM covers WHERE book_id = ?", (book_id,))
                        save_cover_record(db, book_id, cover)
                    db.commit()
                    if cover and cover.filename:
                        delete_unused_cover_file(old_cover)
                    flash("Книга успешно обновлена.", "success")
                    return redirect(url_for("book_detail", book_id=book_id))
                except Exception:
                    db.rollback()
                    flash("При сохранении данных возникла ошибка.", "danger")
            for error in errors:
                flash(error, "danger")
        return render_template("book_form.html", form=form, genres=genres, book=book)

    @app.post("/books/<int:book_id>/delete")
    @roles_required("Администратор")
    def book_delete(book_id):
        db = get_db()
        book = get_book(book_id)
        filename = book["cover_filename"]
        db.execute("DELETE FROM books WHERE id = ?", (book_id,))
        db.commit()
        delete_unused_cover_file(filename)
        flash("Книга успешно удалена.", "success")
        return redirect(url_for("index"))

    @app.route("/books/<int:book_id>/reviews/new", methods=["GET", "POST"])
    @login_required
    def review_create(book_id):
        db = get_db()
        book = get_book(book_id)
        existing = db.execute(
            "SELECT id FROM reviews WHERE book_id = ? AND user_id = ?",
            (book_id, g.user["id"]),
        ).fetchone()
        if existing:
            flash("Вы уже оставляли рецензию на эту книгу.", "warning")
            return redirect(url_for("book_detail", book_id=book_id))
        if request.method == "POST":
            text = sanitize_markdown(request.form.get("text", ""))
            rating = request.form.get("rating", 5, type=int)
            if not text:
                flash("Введите текст рецензии.", "danger")
            elif rating not in RATING_LABELS:
                flash("Выберите допустимую оценку.", "danger")
            else:
                pending_id = db.execute(
                    "SELECT id FROM review_statuses WHERE name = 'На рассмотрении'"
                ).fetchone()["id"]
                db.execute(
                    """
                    INSERT INTO reviews(book_id, user_id, rating, text, status_id)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (book_id, g.user["id"], rating, text, pending_id),
                )
                db.commit()
                flash("Рецензия отправлена на модерацию.", "success")
                return redirect(url_for("book_detail", book_id=book_id))
        return render_template("review_form.html", book=book)

    @app.route("/my-reviews")
    @login_required
    def my_reviews():
        reviews = get_db().execute(
            """
            SELECT reviews.*, books.title AS book_title,
                   review_statuses.name AS status_name
            FROM reviews
            JOIN books ON books.id = reviews.book_id
            JOIN review_statuses ON review_statuses.id = reviews.status_id
            WHERE reviews.user_id = ?
            ORDER BY reviews.created_at DESC
            """,
            (g.user["id"],),
        ).fetchall()
        return render_template("my_reviews.html", reviews=reviews)

    @app.route("/my-collections")
    @roles_required("Пользователь")
    def my_collections():
        collections = get_db().execute(
            """
            SELECT collections.*, COUNT(collection_books.book_id) AS books_count
            FROM collections
            LEFT JOIN collection_books
                   ON collection_books.collection_id = collections.id
            WHERE collections.user_id = ?
            GROUP BY collections.id
            ORDER BY collections.title
            """,
            (g.user["id"],),
        ).fetchall()
        return render_template("my_collections.html", collections=collections)

    @app.post("/my-collections")
    @roles_required("Пользователь")
    def collection_create():
        title = request.form.get("title", "").strip()
        if not title:
            flash("Введите название подборки.", "danger")
        else:
            db = get_db()
            db.execute(
                "INSERT INTO collections(title, user_id) VALUES (?, ?)",
                (title, g.user["id"]),
            )
            db.commit()
            flash("Подборка успешно добавлена.", "success")
        return redirect(url_for("my_collections"))

    @app.route("/my-collections/<int:collection_id>")
    @roles_required("Пользователь")
    def collection_detail(collection_id):
        collection = get_collection(collection_id)
        books = get_db().execute(
            """
            SELECT books.*, covers.filename AS cover_filename,
                   GROUP_CONCAT(genres.name, ', ') AS genre_names
            FROM collection_books
            JOIN books ON books.id = collection_books.book_id
            LEFT JOIN covers ON covers.book_id = books.id
            LEFT JOIN book_genres ON book_genres.book_id = books.id
            LEFT JOIN genres ON genres.id = book_genres.genre_id
            WHERE collection_books.collection_id = ?
            GROUP BY books.id
            ORDER BY books.publication_year DESC, books.title
            """,
            (collection_id,),
        ).fetchall()
        return render_template(
            "collection_detail.html", collection=collection, books=books
        )

    @app.post("/books/<int:book_id>/collections")
    @roles_required("Пользователь")
    def add_book_to_collection(book_id):
        get_book(book_id)
        collection_id = request.form.get("collection_id", type=int)
        if collection_id is None:
            flash("Выберите подборку.", "danger")
            return redirect(url_for("book_detail", book_id=book_id))
        get_collection(collection_id)
        db = get_db()
        cursor = db.execute(
            """
            INSERT OR IGNORE INTO collection_books(collection_id, book_id)
            VALUES (?, ?)
            """,
            (collection_id, book_id),
        )
        db.commit()
        if cursor.rowcount:
            flash("Книга успешно добавлена в подборку.", "success")
        else:
            flash("Эта книга уже входит в выбранную подборку.", "warning")
        return redirect(url_for("book_detail", book_id=book_id))

    @app.route("/moderation")
    @roles_required("Администратор", "Модератор")
    def moderation():
        page = max(request.args.get("page", 1, type=int), 1)
        per_page = 10
        db = get_db()
        where = "WHERE review_statuses.name = 'На рассмотрении'"
        total = db.execute(
            f"""
            SELECT COUNT(*) AS count FROM reviews
            JOIN review_statuses ON review_statuses.id = reviews.status_id {where}
            """
        ).fetchone()["count"]
        reviews = db.execute(
            f"""
            SELECT reviews.*, books.title AS book_title,
                   users.last_name || ' ' || users.first_name AS user_name
            FROM reviews
            JOIN books ON books.id = reviews.book_id
            JOIN users ON users.id = reviews.user_id
            JOIN review_statuses ON review_statuses.id = reviews.status_id
            {where}
            ORDER BY reviews.created_at
            LIMIT ? OFFSET ?
            """,
            (per_page, (page - 1) * per_page),
        ).fetchall()
        pages = max((total + per_page - 1) // per_page, 1)
        return render_template(
            "moderation.html", reviews=reviews, page=page, pages=pages
        )

    @app.route("/moderation/<int:review_id>")
    @roles_required("Администратор", "Модератор")
    def moderation_detail(review_id):
        return render_template("moderation_detail.html", review=get_review(review_id))

    @app.post("/moderation/<int:review_id>/<action>")
    @roles_required("Администратор", "Модератор")
    def moderate_review(review_id, action):
        status_name = {"approve": "Одобрена", "reject": "Отклонена"}.get(action)
        if status_name is None:
            abort(404)
        db = get_db()
        get_review(review_id)
        status_id = db.execute(
            "SELECT id FROM review_statuses WHERE name = ?", (status_name,)
        ).fetchone()["id"]
        db.execute("UPDATE reviews SET status_id = ? WHERE id = ?", (status_id, review_id))
        db.commit()
        flash(f"Статус рецензии изменён: {status_name}.", "success")
        return redirect(url_for("moderation"))

    @app.errorhandler(413)
    def file_too_large(_error):
        flash("Файл слишком большой. Максимальный размер — 5 МБ.", "danger")
        return redirect(request.referrer or url_for("index"))


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
