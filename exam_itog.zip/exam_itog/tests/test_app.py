import io
import os
import tempfile
import unittest

from app import AUTH_REQUIRED_MESSAGE, create_app


class LibraryAppTestCase(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.app = create_app(
            {
                "TESTING": True,
                "SECRET_KEY": "test",
                "DATABASE": os.path.join(self.temp_dir.name, "test.db"),
                "UPLOAD_FOLDER": os.path.join(self.temp_dir.name, "uploads"),
            }
        )
        self.client = self.app.test_client()

    def tearDown(self):
        self.temp_dir.cleanup()

    def login(self, login, password):
        return self.client.post(
            "/login", data={"login": login, "password": password}, follow_redirects=True
        )

    def test_catalog_is_public(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Каталог книг".encode(), response.data)

    def test_private_page_redirects_to_login(self):
        response = self.client.get("/books/new", follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(AUTH_REQUIRED_MESSAGE.encode(), response.data)

    def test_reader_cannot_add_book(self):
        self.login("reader", "reader")
        response = self.client.get("/books/new", follow_redirects=True)
        self.assertIn("недостаточно прав".encode(), response.data)

    def test_admin_can_add_book(self):
        self.login("admin", "admin")
        response = self.client.post(
            "/books/new",
            data={
                "title": "Тестовая книга",
                "description": "**Описание**",
                "publication_year": "2026",
                "publisher": "Тест",
                "author": "Автор",
                "pages": "100",
                "genre_ids": "1",
                "cover": (io.BytesIO(b"fake image data"), "cover.png"),
            },
            content_type="multipart/form-data",
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("Тестовая книга".encode(), response.data)

    def test_admin_can_add_book_with_cyrillic_cover_filename(self):
        self.login("admin", "admin")
        response = self.client.post(
            "/books/new",
            data={
                "title": "Книга с кириллической обложкой",
                "description": "Описание",
                "publication_year": "2026",
                "publisher": "Тест",
                "author": "Автор",
                "pages": "100",
                "genre_ids": "1",
                "cover": (io.BytesIO(b"another fake image"), "обложка.png"),
            },
            content_type="multipart/form-data",
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("Книга с кириллической обложкой".encode(), response.data)

    def test_review_requires_moderation(self):
        self.login("reader", "reader")
        response = self.client.post(
            "/books/1/reviews/new",
            data={"rating": "5", "text": "Отличная книга"},
            follow_redirects=True,
        )
        self.assertIn("отправлена на модерацию".encode(), response.data)
        response = self.client.get("/books/1")
        self.assertNotIn("Отличная книга".encode(), response.data)

    def test_reader_can_create_collection_and_add_book(self):
        self.login("reader", "reader")
        response = self.client.post(
            "/my-collections",
            data={"title": "Любимые книги"},
            follow_redirects=True,
        )
        self.assertIn("Подборка успешно добавлена".encode(), response.data)
        self.assertIn("Любимые книги".encode(), response.data)
        response = self.client.post(
            "/books/1/collections",
            data={"collection_id": "1"},
            follow_redirects=True,
        )
        self.assertIn("Книга успешно добавлена в подборку".encode(), response.data)
        response = self.client.get("/my-collections/1")
        self.assertIn("Мастер и Маргарита".encode(), response.data)

    def test_reader_cannot_add_book_to_another_users_collection(self):
        with self.app.app_context():
            db = self.app.extensions.get("db")
            if db is None:
                from app import get_db

                db = get_db()
            user_id = db.execute(
                "SELECT id FROM users WHERE login = 'admin'"
            ).fetchone()["id"]
            db.execute(
                "INSERT INTO collections(title, user_id) VALUES (?, ?)",
                ("Чужая подборка", user_id),
            )
            db.commit()
        self.login("reader", "reader")
        response = self.client.post("/books/1/collections", data={"collection_id": "1"})
        self.assertEqual(response.status_code, 404)

    def test_collections_page_is_only_for_readers(self):
        self.login("admin", "admin")
        response = self.client.get("/my-collections", follow_redirects=True)
        self.assertIn("недостаточно прав".encode(), response.data)


if __name__ == "__main__":
    unittest.main()
